<a href="http://gruntjs.com" target="_blank"><img src="https://cdn.gruntjs.com/builtwith.png" alt="Built with Grunt"></a> 
# Dropper 

A jQuery plugin for simple drag and drop uploads. Part of the Formstone Library. 

- [Demo](http://formstone.it/components/Dropper/demo/index.html) 
- [Documentation](http://formstone.it/dropper/) 

#### Bower Support 
`bower install Dropper`